
const express = require('express');
const cors = require('cors');
const { ethers } = require('ethers');

const app = express();
app.use(cors());

const PORT = process.env.PORT || 8080;
const PMH_CONTRACT = '0x1CA466c720021ACf885370458092BdD8De48FE01';
const ABI = ['function lastClaim(address) view returns (uint256)'];

const provider = new ethers.providers.JsonRpcProvider('https://rpc.worldchain.xyz');
const contract = new ethers.Contract(PMH_CONTRACT, ABI, provider);

const COOLDOWN = 60 * 60 * 12; // 12 hours in seconds

app.get('/check-cooldown', async (req, res) => {
  const { address } = req.query;
  if (!ethers.utils.isAddress(address)) {
    return res.status(400).json({ error: 'Invalid address' });
  }

  try {
    const lastClaim = await contract.lastClaim(address);
    const now = Math.floor(Date.now() / 1000);
    const diff = now - lastClaim.toNumber();

    if (diff >= COOLDOWN) {
      return res.json({ canClaim: true, cooldownSeconds: 0 });
    } else {
      return res.json({ canClaim: false, cooldownSeconds: COOLDOWN - diff });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error fetching cooldown' });
  }
});

app.listen(PORT, () => console.log(`Listening on ${PORT}`));
