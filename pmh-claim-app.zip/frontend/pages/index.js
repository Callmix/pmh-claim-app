
// pages/index.js
import { useEffect, useState } from 'react';
import { useAccount, useContractRead, useContractWrite, useWaitForTransaction } from 'wagmi';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { ethers } from 'ethers';

const PMH_CONTRACT = '0x1CA466c720021ACf885370458092BdD8De48FE01';
const ABI = [
  "function claim()",
  "function balanceOf(address) view returns (uint256)"
];

const BACKEND_API = 'https://your-ngrok-url.ngrok-free.app/check-cooldown';
const ALCHEMY_URL = 'https://worldchain-mainnet.g.alchemy.com/v2/weYyU4qQIupaBqhOYgzik9B2C8Ci0NmG';

export default function Home() {
  const { address, isConnected } = useAccount();
  const [cooldown, setCooldown] = useState(null);
  const [fetchingCooldown, setFetchingCooldown] = useState(false);
  const [claimHistory, setClaimHistory] = useState([]);

  const { data: balance } = useContractRead({
    address: PMH_CONTRACT,
    abi: ABI,
    functionName: 'balanceOf',
    args: [address],
    watch: true,
    enabled: !!address
  });

  const { write: claim, data: claimTx, isLoading: claiming } = useContractWrite({
    address: PMH_CONTRACT,
    abi: ABI,
    functionName: 'claim',
  });

  const { isSuccess: claimConfirmed } = useWaitForTransaction({
    hash: claimTx?.hash,
  });

  useEffect(() => {
    if (!address) return;

    // Cooldown checker
    setFetchingCooldown(true);
    fetch(`${BACKEND_API}?address=${address}`)
      .then(res => res.json())
      .then(data => setCooldown(data))
      .catch(err => console.error(err))
      .finally(() => setFetchingCooldown(false));

    // Claim history
    const headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    };
    const body = JSON.stringify({
      id: 1,
      jsonrpc: "2.0",
      method: "alchemy_getAssetTransfers",
      params: [
        {
          fromBlock: "0x0",
          toBlock: "latest",
          toAddress: address,
          contractAddresses: [PMH_CONTRACT],
          withMetadata: false,
          excludeZeroValue: true,
          category: ["erc20"]
        }
      ]
    });

    fetch(ALCHEMY_URL, {
      method: 'POST',
      headers,
      body
    })
      .then(res => res.json())
      .then(data => {
        if (data?.result?.transfers) setClaimHistory(data.result.transfers);
      })
      .catch(console.error);

  }, [address, claimConfirmed]);

  const formatTime = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs}h ${mins}m ${secs}s`;
  };

  return (
    <div className="min-h-screen p-6 max-w-lg mx-auto space-y-6">
      <h1 className="text-2xl font-bold">PMH Claim App</h1>

      <ConnectButton />

      {isConnected && (
        <>
          <div className="text-sm text-gray-700">
            <p><strong>Address:</strong> {address}</p>
            <p><strong>Balance:</strong> {balance ? ethers.utils.formatUnits(balance, 18) : '0'} PMH</p>
          </div>

          <div className="mt-4">
            <button
              onClick={() => claim?.()}
              disabled={!cooldown?.canClaim || claiming}
              className="bg-blue-600 text-white py-2 px-4 rounded disabled:bg-gray-400"
            >
              {claiming ? 'Claiming...' : 'Claim PMH'}
            </button>
            {cooldown && !cooldown.canClaim && (
              <p className="text-xs mt-2 text-red-600">
                Cooldown active: {formatTime(cooldown.cooldownSeconds)} left
              </p>
            )}
          </div>

          {claimConfirmed && (
            <p className="text-green-600 text-sm mt-4">Claim successful!</p>
          )}

          {claimHistory.length > 0 && (
            <div className="mt-6">
              <h3 className="font-semibold">Claim History:</h3>
              <ul className="text-xs mt-2 space-y-1">
                {claimHistory.map((tx, i) => (
                  <li key={i}>
                    {new Date(tx.metadata?.blockTimestamp || tx.blockNum * 1000).toLocaleString()} —
                    +{ethers.utils.formatUnits(tx.value, 18)} PMH from {tx.from}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}
    </div>
  );
}
